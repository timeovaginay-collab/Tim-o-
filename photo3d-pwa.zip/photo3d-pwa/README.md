# Photo → 3D IA

Application web progressive (PWA) de reconstruction 3D par IA depuis vos photos.

## Déploiement sur GitHub Pages (gratuit, 5 minutes)

### Étape 1 — Créer un compte GitHub
1. Va sur **github.com**
2. Clique **Sign up** → crée un compte gratuit

### Étape 2 — Créer le dépôt
1. Connecté sur GitHub, clique sur le **+** en haut à droite → **New repository**
2. Nom du dépôt : `photo3d` (ou ce que tu veux)
3. Laisse tout par défaut → clique **Create repository**

### Étape 3 — Uploader les fichiers
Sur la page du dépôt vide :
1. Clique **uploading an existing file**
2. Glisse-dépose ces 4 fichiers/dossiers :
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `.github/` (dossier entier)
3. Clique **Commit changes**

### Étape 4 — Activer GitHub Pages
1. Dans ton dépôt → **Settings** (onglet en haut)
2. Dans le menu gauche → **Pages**
3. Source → **GitHub Actions**
4. Sauvegarde

### Étape 5 — Attendre le déploiement (2 min)
1. Va dans l'onglet **Actions** de ton dépôt
2. Tu verras un workflow "Deploy to GitHub Pages" en cours
3. Quand c'est vert → ton app est en ligne !

### Étape 6 — Accéder à ton app
L'URL sera : `https://TON_USERNAME.github.io/photo3d/`

Tu peux l'ouvrir depuis n'importe quel navigateur, Android, iPhone, PC.
Sur Android Chrome : bouton "Ajouter à l'écran d'accueil" → ça fonctionne comme une vraie app !

## Moteurs IA disponibles

| Moteur | Qualité | Gratuit | Clé requise |
|--------|---------|---------|-------------|
| TripoSG (Stability AI) | ⭐⭐⭐⭐ | ✅ | Non |
| Hunyuan3D (Tencent) | ⭐⭐⭐⭐⭐ | ✅ | Non |
| Meshy AI | ⭐⭐⭐⭐⭐ | ✅ 200 crédits | Oui (gratuite) |
| Local | ⭐⭐ | ✅ | Non |

## Formats d'export
- **STL** — impression 3D classique
- **OBJ** — Blender, MeshLab
- **GLB** — avec textures (si IA)
